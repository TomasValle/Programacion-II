from __future__ import annotations
from typing import Dict, List, Set


class Student:
    student_id: int
    name: str
    courses: Set[Course]
    scores: Dict[Course: List[int]]
    students: Dict[int: Student] = {}

    def __init__(self, id_number: int, name: str):
        self.student_id = id_number
        self.name = name
        self.courses = set()
        self.scores = {}
        Student.students[self.student_id] = self

    @staticmethod
    def get_student(student_id: int) -> Student:
        return Student.students[student_id]

    def __repr__(self):
        return f'{self.student_id}-{self.name}'

    def get_scores(self) -> Dict[Course, List[int]]:
        return self.scores


class Course:
    course_id: str
    description: str
    students: Set[Student]
    exams:  Dict[int: List[int]]
    courses: Dict[int: Course] = {}

    def __init__(self, course_id: str, description: str):
        self.course_id = course_id
        self.description = description
        self.students = set()
        self.exams = {}
        Course.courses[self.course_id] = self

    def __repr__(self) -> str:
        return f'{self.course_id}-{self.description}'

    @staticmethod
    def get_course(course_id: str) -> Course:
        return Course.courses[course_id]

    def enroll(self, student_id: int):
        student = Student.students[student_id]
        self.students.add(student)
        student.courses.add(self)

    def add_exam(self, student_id: int, score: int):
        self.exams[student_id].append(score)
        student = Student.students[student_id]
        if self not in student.scores:
            student.scores[self] = []
        student.scores[self].append(score)

    def get_student(self, student_id: int) -> Student:
        pass

    def get_scores(self, student_id: int) -> List[int]:
        if student_id not in self.exams:
            self.exams[student_id] = []
        return self.exams[student_id]
