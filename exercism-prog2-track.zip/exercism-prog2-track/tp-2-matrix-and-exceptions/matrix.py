from __future__ import annotations
from typing import List

Matrix = List[List[float]]

class Matrix:

    def __init__(self, matrix: List[List[float]]) -> None:
        self.matrix = matrix
        self.num_rows = len(matrix)
        if self.num_rows == 0:
            self.num_columns = 0
        else:
            self.num_columns = len(matrix[0])

    def __mul__(self, other: Matrix | int) -> Matrix:
        if type(other) == Matrix:
            c: Matrix = [[0 for j in range(other.num_columns)] for i in range(self.num_rows)]
            if self.num_columns == other.num_rows:
                for i in range(self.num_rows):
                    for j in range(other.num_columns):
                        for z in range(self.num_columns):
                            c[i][j] += self.matrix[i][z] * other.matrix[z][j]
                return Matrix(c)
            else:
                raise ValueError(f"Incompatibles dimensions A = {self.num_rows}x{self.num_columns},"
                                 f" B = {other.num_rows}x{other.num_columns}")
        elif type(other) == int:
            for i in range(self.num_rows):
                for j in range(self.num_columns):
                    self.matrix[i][j] *= other
            return self
        else:
            raise ValueError("Argument should be a Matrix or a scalar int")

    def __add__(self, other: Matrix) -> Matrix:
        if (self.num_rows != other.num_rows) or (self.num_columns != other.num_columns):
            raise ValueError(f"Matrices should have the same dimensions!")
        else:
            c: Matrix = [[0 for j in range(self.num_columns)] for i in range(self.num_rows)]
            for i in range(self.num_rows):
                for j in range(self.num_columns):
                    c[i][j] = self.matrix[i][j] + other.matrix[i][j]
            return Matrix(c)

    def __invert__(self):
        c: Matrix = [[0 for j in range(self.num_rows)] for i in range(self.num_columns)]
        for i in range(self.num_columns):
            for j in range(self.num_rows):
                c[i][j] += self.matrix[j][i]
        return Matrix(c)
