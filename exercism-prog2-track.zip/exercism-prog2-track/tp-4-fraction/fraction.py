from __future__ import annotations
import math


class Fraction:
    numerator: int
    denominator: int

    def __init__(self, n: int, d: int) -> None:
        self.numerator: int = n
        self.denominator: int = d

    def gcd(self) -> int:
        g: int = math.gcd(self.numerator, self.denominator)
        return g

    def reduce(self) -> Fraction | int:
        g = self.gcd()
        if self.denominator // g == 1:
            return self.numerator // g
        elif self.denominator // g == -1:
            return -self.numerator // g
        else:
            return Fraction(self.numerator // g, self.denominator // g)

    def sign(self):
        if self.numerator < 0 and self.denominator < 0:
            return Fraction(self.numerator * -1, self.denominator * -1)
        elif self.denominator < 0:
            return Fraction(self.numerator * -1, self.denominator * -1)
        else:
            return Fraction(self.numerator, self.denominator)

    def __repr__(self) -> str:
        return f'{self.numerator}/{self.denominator}'

    def __eq__(self, other) -> bool:
        self_1 = self.sign()
        other_1 = other.sign()
        s_g: int = self_1.gcd()
        o_g: int = other_1.gcd()
        return self_1.numerator//s_g == other_1.numerator//o_g and self_1.denominator//s_g == other_1.denominator//o_g

    def __mul__(self, other: Fraction) -> Fraction | int:
        return Fraction(self.numerator * other.numerator, self.denominator * other.denominator).reduce()

    def __add__(self, other: Fraction) -> Fraction | int:
        if self.denominator == other.denominator:
            return Fraction(self.numerator + other.numerator, self.denominator).reduce()
        else:
            numerator = (self.numerator * other.denominator) + (other.numerator * self.denominator)
            return Fraction(numerator, self.denominator * other.denominator).reduce()

    def __sub__(self, other: Fraction) -> Fraction | int:
        if self.denominator == other.denominator:
            return Fraction(self.numerator - other.numerator, self.denominator).reduce()
        else:
            numerator = (self.numerator * other.denominator) - (other.numerator * self.denominator)
            return Fraction(numerator, self.denominator * other.denominator).reduce()

    def __truediv__(self, other: Fraction) -> Fraction | int:
        return Fraction(self.numerator * other.denominator, self.denominator * other.numerator).reduce()


def gcd(a: int, b: int) -> int:
    pass
