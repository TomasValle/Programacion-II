import unittest

from fraction import (Fraction, gcd)


class FractionTest(unittest.TestCase):
    def test_creation(self):
        f = Fraction(1, 2)
        self.assertEqual(1, f.numerator)
        self.assertEqual(2, f.denominator)

    def test_str(self):
        f = Fraction(1, 2)
        self.assertEqual("1/2", str(f))

    def test_str2(self):
        f = Fraction(2, 4)
        self.assertEqual("2/4", str(f))

    def test_eq(self):
        f1 = Fraction(1, 2)
        f2 = Fraction(1, 2)
        self.assertTrue(f1 == f2)

    def test_eq2(self):
        f1 = Fraction(1, 2)
        f2 = Fraction(1, 3)
        self.assertFalse(f1 == f2)

    def test_creation_simplifying(self):
        f12 = Fraction(1, 2)
        f24 = Fraction(2, 4)
        self.assertEqual(f12, f24)

    def test_creation_simplifying2(self):
        f12 = Fraction(-1, 2)
        f24 = Fraction(2, -4)
        self.assertEqual(f12, f24)

    def test_creation_simplifying3(self):
        f12 = Fraction(1, 2)
        f24 = Fraction(-2, -4)
        self.assertEqual(f12, f24)

    def test_creation_simplifying4(self):
        f12 = Fraction(1, 2)
        f34 = Fraction(3, 4)
        self.assertFalse(f12 == f34)

    def test_mul(self):
        result = Fraction(1, 2) * Fraction(1, 4)
        self.assertEqual(Fraction(1, 8), result)

    def test_mul2(self):
        result = Fraction(1, 2) * Fraction(1, 4)
        self.assertFalse(Fraction(1, 6) == result)

    def test_add(self):
        result = Fraction(1, 3) + Fraction(3, 4)
        self.assertEqual(Fraction(13, 12), result)

    def test_add2(self):
        result = Fraction(1, 2) + Fraction(2, 4)
        self.assertEqual(1, result)

    def test_sub(self):
        result = Fraction(5, 6) - Fraction(2, 3)
        self.assertEqual(Fraction(1, 6), result)

    def test_sub2(self):
        result = Fraction(1, 2) - Fraction(-6, -4)
        self.assertEqual(-1, result)

    def test_div(self):
        result = Fraction(1, 2) / Fraction(1, 4)
        self.assertEqual(2, result)

    def test_div2(self):
        result = Fraction(1, 7) / Fraction(1, 4)
        self.assertEqual(Fraction(4, 7), result)

    # def test_gcd(self):
    #     self.assertEqual(6, gcd(42, 30))
    #     self.assertEqual(6, gcd(-42, 30))
    #     self.assertEqual(6, gcd(42, -30))
