from typing import Callable, List

import math


def encrypt_with_char(message: str, key: str, word:str = '') -> str:
    if len(message) == 0:
        return word
    elif len(message) == 1:
        return word + chr(ord(message[0]) ^ ord(key))
    else:
        return encrypt_with_char(message[1:], key, word + chr(ord(message[0]) ^ ord(key)))


def encrypt(message: str, password: str) -> str:
    word: str = ''
    i: int = 0
    if len(message) == 0:
        return ''
    while 0 < len(message):
        word += chr(ord(message[0]) ^ ord(password[i]))
        message: str = message[1:]
        i += 1
        if i >= len(password):
            i = 0
    return word
