import re
from typing import Dict


codon_to_protein: Dict[str, str] = {
    "AUG": "Methionine",
    "UUU": "Phenylalanine",
    "UUC": "Phenylalanine",
    "UUA": "Leucine",
    "UUG": "Leucine",
    "UCU": "Serine",
    "UCC": "Serine",
    "UCA": "Serine",
    "UCG": "Serine",
    "UAU": "Tyrosine",
    "UAC": "Tyrosine",
    "UGU": "Cysteine",
    "UGC": "Cysteine",
    "UGG": "Tryptophan",
    "UAA": "STOP",
    "UAG": "STOP",
    "UGA": "STOP"
    }


def drop_after_stop(translated_proteins):
    if "STOP" in translated_proteins:
        stop_index = translated_proteins.index("STOP")
        return translated_proteins[:stop_index]
    return translated_proteins


def proteins(strand):
    codons = re.findall("...", strand)
    translated_proteins = list(map(lambda codon: codon_to_protein.get(codon), codons))
    return drop_after_stop(translated_proteins)
