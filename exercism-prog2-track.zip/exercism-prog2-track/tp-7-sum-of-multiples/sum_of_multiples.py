import operator
from functools import reduce
from typing import List


def sum_of_multiples(limit: int, multiples: List[int]):
    non_zero_multiples = list(filter(lambda x: x != 0, multiples))
    lista_rango = list(range(limit))
    filtered_list = list(filter(lambda x: is_divisible_by(x, non_zero_multiples), lista_rango))
    return reduce(operator.add, filtered_list, 0)


def is_divisible_by(x: int, multiples: List[int]) -> bool:
    for elem in multiples:
        if x % elem == 0:
            return True
    return False
