from __future__ import annotations

from functools import reduce
import operator
import math
from abc import abstractmethod
from typing import List


class Shape:

    def __init__(self):
        pass

    @staticmethod
    def sum_areas(shapes: List[Shape]):
        return reduce(lambda acc, val: acc + val.area(), shapes, 0)

    @staticmethod
    def min_area(shapes: List[Shape]):
        return reduce(lambda a, b: a if a < b else b, list(map(lambda val: val.area(), shapes)))

    @staticmethod
    def max_area(shapes: List[Shape]):
        return reduce(lambda a, b: a if a > b else b, list(map(lambda val: val.area(), shapes)))

    @staticmethod
    def sum_perimeters(shapes: List[Shape]):
        return reduce(lambda acc, val: acc + val.perimeter(), shapes, 0)

    @staticmethod
    def min_perimeter(shapes: List[Shape]):
        return reduce(lambda a, b: a if a < b else b, list(map(lambda val: val.perimeter(), shapes)))

    @staticmethod
    def max_perimeter(shapes: List[Shape]):
        return reduce(lambda a, b: a if a > b else b, list(map(lambda val: val.perimeter(), shapes)))

    @abstractmethod
    def area(self) -> float: pass

    @abstractmethod
    def perimeter(self) -> float: pass


class Circle(Shape):
    radius: float

    def __init__(self, radius):
        super().__init__()
        self.radius = radius

    def area(self) -> float:
        return math.pi * self.radius ** 2

    def perimeter(self) -> float:
        return 2 * math.pi * self.radius


class Triangle(Shape):
    a: float
    b: float
    c: float

    def __init__(self, a, b, c):
        super().__init__()
        self.a = a
        self.b = b
        self.c = c

    def area(self) -> float:
        s = (self.a + self.b + self.c)/2
        return math.sqrt(s * (s - self.a) * (s - self.b) * (s - self.c))

    def perimeter(self) -> float:
        return self.a + self.b + self.c


class Rectangle(Shape):
    base: float
    height: float

    def __init__(self, base, height):
        super().__init__()
        self.base = base
        self.height = height

    def area(self) -> float:
        return self.base * self.height

    def perimeter(self) -> float:
        return self.base * 2 + self.height * 2


class Square(Rectangle):
    base: float

    def __init__(self, base):
        super().__init__(base, height=0)
        self.height = base
