"""Functions for compiling dishes and ingredients for a catering company."""


from sets_categories_data import (VEGAN,
                                  VEGETARIAN,
                                  KETO,
                                  PALEO,
                                  OMNIVORE,
                                  ALCOHOLS,
                                  SPECIAL_INGREDIENTS)


def clean_ingredients(dish_name, dish_ingredients):
    ingredient_set = set(dish_ingredients)
    return dish_name, ingredient_set


def check_drinks(drink_name, drink_ingredients):
    ingredient_set = set(drink_ingredients)
    if len(ingredient_set.intersection(ALCOHOLS)) == 0:
        return f'{drink_name} Mocktail'
    else:
        return f'{drink_name} Cocktail'


def categorize_dish(dish_name, dish_ingredients):
    categories = [VEGAN, VEGETARIAN, KETO, PALEO, OMNIVORE, ALCOHOLS, SPECIAL_INGREDIENTS]
    names = ["VEGAN", "VEGETARIAN", "KETO", "PALEO", "OMNIVORE", "ALCOHOLS", "SPECIAL_INGREDIENTS"]
    i = 0
    for category in categories:
        if dish_ingredients.issubset(category) is True:
            return f'{dish_name}: {names[i]}'
        else:
            i += 1


def tag_special_ingredients(dish):
    name = dish[0]
    ingredients_set = set(dish[1])
    special_ingredients_dish = ingredients_set.intersection(SPECIAL_INGREDIENTS)
    return name, special_ingredients_dish


def compile_ingredients(dishes):
    master_set = set()
    for dish in dishes:
        master_set = master_set.union(dish)
    return master_set


def separate_appetizers(dishes, appetizers):
    dishes = set(dishes)
    appetizers = set(appetizers)
    true_dishes = dishes.difference(appetizers)
    return true_dishes


def singleton_ingredients(dishes, intersection):
    for i in intersection:
        for d in dishes:
            d.discard(i)
    return compile_ingredients(dishes)


