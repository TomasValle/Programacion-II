"""Functions to keep track and alter inventory."""


def create_inventory(items):
    inventory = {}
    for item in items:
        inventory[item] = inventory.get(item, 0) + 1
    return inventory


def add_items(inventory, items):
    for item in items:
        if item in inventory:
            inventory[item] = inventory.get(item) + 1
        else:
            inventory[item] = inventory.get(item, 0) + 1
    return inventory


def decrement_items(inventory, items):
    for item in items:
        if item in inventory:
            if inventory.get(item) > 0:
                inventory[item] = inventory.get(item) - 1
    return inventory


def remove_item(inventory, item):
    if item in inventory:
        inventory.pop(item)
        return inventory
    else:
        return inventory


def list_inventory(inventory):
    keys = list(inventory.keys())
    values = list(inventory.values())
    list_par = []
    for i in range(len(inventory)):
        par = keys[i], values[i]
        if par[1] > 0:
            list_par.append(par)
    return list_par
