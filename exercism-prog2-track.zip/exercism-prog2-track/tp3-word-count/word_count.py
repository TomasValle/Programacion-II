from typing import Dict


def count_words(sentence) -> Dict[str, int]:
    my_punctuation = r'!#$%&"()*+, -./:;<=>?@[\]^_`{|}~'

    punctuation_dictionary: Dict[str, str] = {}
    for j in my_punctuation:
        punctuation_dictionary.update({j: " "})

    my_table = sentence.maketrans(punctuation_dictionary)
    new_sentence = sentence.translate(my_table).strip().strip("'")

    new_sentence_list = new_sentence.lower().split()

    for i in range(len(new_sentence_list)):
        if new_sentence_list[i][0] == "'":
            new_sentence_list[i] = new_sentence_list[i].replace("'", "")

    counts: Dict[str, int] = {}
    for word in new_sentence_list:
        counts[word] = counts.get(word, 0) + 1
    return counts
